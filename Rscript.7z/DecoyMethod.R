##-----------------------------Functions only----------------------------------------##
##-----------------------------Functions only----------------------------------------##
##-----------------------------Functions only----------------------------------------##

##---Please use the RunExampleCases.R to run these functions---##

#Reverse
ReverseDecoy<-function(Seq)
{
return(stri_reverse(Seq))
}

#PseudoReverseKR
PseudoReverseKR<-function(Seq)
{
XXa<-unlist(strsplit(Seq,""))
KRsite<-grep("[KR]" ,XXa)
result<-NULL
if(length(KRsite)!=0)
{
for(i in c(1:length(KRsite)))
{ 
       if(i==1)
       { 
         if(2-(KRsite[i]-1)!=1 && (KRsite[i]-1)!=0)
           {
        	result<-c(result,c(XXa[  sort((1: (KRsite[i]-1)),decreasing = T) ], XXa[KRsite[i]]))
            }else{
                  if((KRsite[i]-1)!=0)
                  {
                    result<-c(result,c(XXa[1],XXa[2]))
                   }else{
                      result<-c(result,c(XXa[1]))
                         }
                 }
       }else{
                if( ((KRsite[i-1])+1)-(KRsite[i]-1) !=1)
                   {
                     result<-c(result,c(XXa[  sort(  ((KRsite[i-1])+1): (KRsite[i]-1),decreasing = T) ], XXa[KRsite[i]]))
                   }else{
      	         result<-c(result,XXa[KRsite[i]])
                         }
              } 
}
         if(i==length(KRsite)&& KRsite[i]!=length(XXa))
         {
                   result<-c(result,XXa[sort((KRsite[i]+1):length(XXa),decreasing = T)])
          }

return(pasteCols(as.matrix(result),sep=""))
}else{
   return(stri_reverse(Seq))
  }


}



#PseudoShuffle_KR
PseudoShuffle_KR<-function(Seq) 
{
XXa<-unlist(strsplit(Seq,""))
KRsite<-grep("[KR]" ,XXa)
if(length(KRsite)!=0)
{
result<-NULL
for(i in c(1:length(KRsite)))
{ 
       if(i==1)
       {
         if((KRsite[i]-1)!=1 && (KRsite[i]-1)!=0)
         {
        	 t1s<-(1: (KRsite[i]-1))
        
        	  if(length(t1s)==1)
        	  {
			 QwXZ<-t1s
         	  }else{
			 	QwXZ<-sample(t1s)
         	       }
       	   result<-c(result,c(XXa[ QwXZ  ], XXa[KRsite[i]]))
         }else{
                    if((KRsite[i]-1)!=0)
                    {
        	         result<-c(result,c(XXa[1],XXa[2]))
                     }else{
        	             result<-c(result,c(XXa[1]))
                          }
         	    }
       }else{
             	 if(((KRsite[i-1])+1)-(KRsite[i]-1)!=1)
             	{
                	  t1s<-((KRsite[i-1])+1): (KRsite[i]-1)
         			if(length(t1s)==1)
         			{
					QwXZ<-t1s
         			}else if(length(t1s)==2)
                             {
					     QwXZ<-sort(t1s,decreasing = T)
                             }else{
					     QwXZ<-sample(t1s)
         			          }
               	  result<-c(result,c(XXa[  QwXZ ], XXa[KRsite[i]]))
                  }else{
       	         result<-c(result,XXa[KRsite[i]])
                       }
              } 
}
         if(i==length(KRsite)&& KRsite[i]!=length(XXa))
         {
 			t1s<-(KRsite[i]+1):length(XXa)
         		if(length(t1s)==1)
         		{
				QwXZ<-t1s
         		}else if(length(t1s)==2)
                             {
					     QwXZ<-sort(t1s,decreasing = T)
                             }else{
				         QwXZ<-sample(t1s)
         			            }
                 result<-c(result,XXa[QwXZ])
          }
return(pasteCols(as.matrix(result),sep=""))
}else{
return(pasteCols(as.matrix(sample(XXa)),sep=""))
 }
}




ExtractMCpep<-function(seqT,ProNameR,missedTindex)
{

aa_matrix<-unlist(strsplit(seqT,""))
KR_site<-grep("[KR]",aa_matrix)
if(length(KR_site)!=0)
{
limitAs<-(length(KR_site)-missedTindex)
k<-0
temp<-NULL
while(k<=limitAs)
{
     if(k==0)
     {
           pepNom<-pasteCols(as.matrix(aa_matrix[1:KR_site[k+missedTindex]]))
   			temp<-rbind(temp,paste(ProNameR,k,sep="_Pep"), pepNom)
     }else{
             pepNom<-pasteCols(as.matrix(aa_matrix[(KR_site[k]+1):KR_site[k+missedTindex]]))
   			temp<-rbind(temp,paste(ProNameR,k,sep="_Pep"), pepNom)

          }
      if(k==limitAs)
       {
                           pepNom<-pasteCols(as.matrix(aa_matrix[((KR_site[k+1])+1):length(aa_matrix)]))
   			temp<-rbind(temp,paste(ProNameR,k+1,sep="_Pep"), pepNom)       
       }   

k<-k+1
}
return(temp)
}else{
        return(rbind(paste(ProNameR,1,sep="_Pep"), seqT))
     }

}

