library(plotrix)
library(stringi)
library(data.table)
source("DecoyMethod.R")

##-------------- Decoy Method --------------##
##-------------- Decoy Method --------------## 

##Input: ProteinSequence(sequence in one line, not FASTA format)

#Example of Input
Seq_Input<-"KRSSWRVISSIEQKETUJDWSQ"

#Run Reverse method to generate decoy sequence
ReverseDecoy(Seq_Input)

#Run Pseudo Reverse method to generate decoy sequence, only suitable for Trypsin cleavage site
PseudoReverseKR(Seq_Input)


#Run Pseudo Shuffle method to generate decoy sequence, only suitable for Trypsin cleavage site
PseudoShuffle_KR(Seq_Input)

### For protease's cleavage sites, please use the our web tool "https://comicslab.github.io/gDecoy/"


##-------------- Extract 2MC or 5KR peptides from reference sequence --------------##
##-------------- Extract 2MC or 5KR peptides from reference sequence --------------## 

#Reference protein sequence's info
ProteinHeader<-">sp|O75438|NDUB1_HUMAN"
Seq_Input<-"MVNLLQIVRDHWVHVLVPMGFVIGCYLDRKSDERLTAFRNKSMLFKRELQPSEEVTWK"

#The maximum number of missed cleavage sites allowed within a peptide (set 2 or 5)

#Case 1: set 2
NumberMissedCleavage<-2 

#Run Extract 2MC peptides
ExtractMCpep(Seq_Input,ProteinHeader, NumberMissedCleavage)


#Case 2: set 5
NumberMissedCleavage<-5

#Run Extract 2MC peptides
ExtractMCpep(Seq_Input,ProteinHeader, NumberMissedCleavage)


##--------------- End --------------## 


















